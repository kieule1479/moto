<head>
    <link rel="icon" href="/output-b23/public/template/default/main/images/favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="/output-b23/public/template/default/main/images/favicon.png" type="image/x-icon">
    <?php echo $this->_metaHTTP; ?>
    <?php echo $this->_metaName; ?>
    <title><?php echo $this->_title; ?></title>
    <?php echo $this->_cssFiles; ?>
</head>