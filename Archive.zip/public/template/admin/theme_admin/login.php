<!DOCTYPE html>
<html>

<head>
    <?php require_once 'html/head.php'; ?>
</head>

<body>

    <?php require_once PATH_MODULE . $this->_moduleName . DS . 'views' . DS . $this->_fileView . '.php'; ?>
    
    <?php require_once 'html/script.php'; ?>
    
</body>

</html>