<head>
	<?php echo $this->_metaHTTP; ?>
	<?php echo $this->_metaName; ?>
	<title><?php echo $this->_title; ?></title>
	<?php echo $this->_cssFiles; ?>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
	<script src="<?php echo URL_LIBS ?>plugins/ckeditor/ckeditor.js"></script>
	<script src="<?php echo URL_LIBS ?>plugins/ckfinder/ckfinder.js"></script>
	
</head>