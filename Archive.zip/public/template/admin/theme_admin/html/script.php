<script>
    var THEME_DATA = {
        "moduleName"    : "<?php echo $moduleName   ?>",
        "controllerName": "<?php echo $controllerName   ?>",
    };
</script>

<?php echo $this->_jsFiles ?>