<?php

class IndexValidate extends Validate
{

    function __construct($params)
    {
        parent::__construct($params['form']);
    }

    //===== VALIDATE ======
    public function validate($model)
    {
       
    }

}
