
<?php
	$xhtmlRelatemotos = '';

	if(!empty($this->motoRelate)){
		foreach($this->motoRelate as $key => $value){
			$name	= $value['name'];
	
			$motoID      = $value['id'];
			$catID       = $value['category_id'];
			$motoNameURL = URL::filterURL($name);
			$catNameURL  = URL::filterURL( $value['category_name']);
			$link        = URL::createLink('default', 'moto', 'detail', array('category_id' => $value['category_id'],'moto_id' => $value['id']), "$catNameURL/$motoNameURL-$catID-$motoID.html");
			
			$picture 		= Helper::createImage('moto', '98x150-', $value['picture'],array('class' => 'thumb', 'width' => 60, 'height' => 90));
			$xhtmlRelatemotos 	.= '<div class="new_prod_box">
									<a href="'.$link.'">'.$name.'</a>
									<div class="new_prod_bg">
										<a href="'.$link.'">'.$picture.'</a>
									</div>
								</div>';
		}
	}
	echo $xhtmlRelatemotos . '<div class="clear"></div>';
?>