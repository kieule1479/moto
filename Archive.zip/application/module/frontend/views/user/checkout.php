<?php
$dataForm = $this->user;


// ROW NAME
$inputName  = Helper::input('text', 'form_user[name]', 'form[name]', $dataForm['fullname'], 'form-control form-control-sm');
$rowName    = Helper::row('Họ tên', $inputName, true);

//ROW PHONE
$inputPhone  = Helper::input('number', 'form_user[phone]', 'form[phone]', $dataForm['telephone'], 'form-control form-control-sm');
$rowPhone    = Helper::row('Điện thoại', $inputPhone, true);

// ROW  EMAIL
$inputEmail  = Helper::input('text', 'form_user[email]', 'form[email]', $dataForm['email'], 'form-control form-control-sm', 'readonly');
$rowEmail    = Helper::row('Email', $inputEmail, true);

//ROW FULL NAME
$inputAddress  = Helper::input('text', 'form_user[address]', 'form[address]', $dataForm['address'], 'form-control form-control-sm');
$rowAddress    = Helper::row('Địa chỉ', $inputAddress);

//INPUT TOKEN
$inputToken = Helper::input('hidden', 'form[token]', 'form[token]', time(), null);

//ROW STATUS
// $arrCity  =  ['default' => '-Chọn thành phố-', '0' => 'Hồ Chí Minh', '1' => 'Hà Nội', '2' => 'Hải Phòng', '3' => 'Đà Nẵng'];
// $slbCity  = Helper::select('form[city]', 'custom-select custom-select-sm', $arrCity, $dataForm['city']);
// $rowCity  = Helper::row('Thành phố', $slbCity, true);

//ROW GROUP 
// $inputNote  = Helper::input('text', 'form[note]', 'form[note]', $dataForm['note'], 'form-control form-control-sm');
// $rowNote    = Helper::row('Ghi chú', $inputNote);

$action = isset($this->arrParam['id']) ? 'form&id=' . $this->arrParam['id'] : 'form';

// SAVE
$linkSave       = URL::createLink('fontend', 'user', 'buy');
$btnSave = Helper::button($linkSave, 'btn btn-sm btn-success mr-1', 'Đặt hàng');


//$btnSave        = Helper::createActionButton("javascript:submitForm('$linkSave')", 'btn-success mr-1', 'Đặt hàng');

//===== BUTTON SAVE ======



// Save & New

$linkCancel     = URL::createLink($this->arrParam['module'], $this->arrParam['controller'], 'index');
$btnSave = Helper::button($linkCancel, 'btn btn-sm btn-danger mr-1', 'Cancel');
// $btnCancel      = Helper::createActionButton($linkCancel, 'btn-danger mr-1', 'Cancel');

$inputIDHidden = '';
if (isset($this->arrParam['id'])) {
    $inputIDHidden = Helper::input('hidden', 'form[id]', 'form[id]', $this->arrParam['id'], NULL);
}

foreach ($this->motoInCart as $key => $value) {
    $linkDetail = URL::createLink('frontend', 'moto', 'detail', ['moto_id' => $value['id']]);
    $picture    = URL_UPLOAD . 'moto' . DS . $value['picture'];
    $name       = $value['name'];
    $quantity   = $value['quantity'];
    $id         = $value['id'];
    $price      = $value['price'];
    $newPrice   = ($price - ($price * $data['sale_off'] / 100));
    $totalPrice = $value['totalprice'];
    $total      = $total + $value['totalprice'];

    $xhtml .= '
            <input type="hidden" name="form[moto_id][]" value="' . $id . '" id="input_moto_id_' . $id . '">
            <input type="hidden" name="form[price][]" value="' . $price . '" id="input_price_' . $id . '">
            <input type="hidden" name="form[quantity][]" value="' . $quantity . '" id="input_quantity_' . $id . '">
            <input type="hidden" name="form[name][]" value="' . $name . '" id="input_name_' . $id . '">
            <input type="hidden" name="form[picture][]" value="' . $value['picture'] . '" id="input_picture_' . $id . '">
    ';

}

$xhtmlInput =  $rowName .$rowEmail .$rowPhone.  $rowAddress. $rowCity. $rowNote. $inputToken. $inputIDHidden. $xhtml;




//!=================================================== END PHP =======================================================
?>
<div class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="page-title">
                    <h2 class="py-2">Thông tin đặt hàng</h2>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $this->errors; ?>

<div class="card card-info card-outline">
    <div class="card-body">
        <form action="" method="post" class="mb-0" id="admin-form">
            <?php echo $xhtmlInput ?>
            

            <div class="col-6"><button type="submit" class="btn btn-solid">Xác nhận</button></div>
        </form>
    </div>
    <div class="card-footer">
        <div class="col-12 col-sm-8 offset-sm-2">

        </div>

    </div>
</div>