
<?php 

$xhtmlSlider='';
foreach ($this->slider as $value) {
    $xhtmlSlider .=    Helper::slider($value['picture']);
}


?>

<!-- SLIDER  -->        
<section class="p-0 my-home-slider">
    <div class="slide-1 home-slider">

    <?php echo $xhtmlSlider; ?>
       
      
    </div>
</section><!-- END SLIDER  -->