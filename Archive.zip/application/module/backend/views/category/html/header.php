
<!-- HEADER -->
<div class="card-header">
    <h4 class="card-title">List</h4>
    <div class="card-tools">
        <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
            <i class="fas fa-minus"></i></button>
    </div>
</div><!-- END HEADER -->