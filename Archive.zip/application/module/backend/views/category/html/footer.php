<!-- FOOTER -->
<div class="card-footer clearfix">
    <ul class="pagination pagination-sm m-0 float-right">
        <?= $this->pagination->showPaginationAdmin() ?>
    </ul>
</div><!-- END FOOTER -->