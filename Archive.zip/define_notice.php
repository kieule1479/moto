<?php
define('SUCCESS_LOGIN', 'Đăng nhập thành công!');
define('SUCCESS_DELETE', 'Xóa dữ liệu thành công!');
define('SUCCESS_ADD', 'Thêm dữ liệu thành công!');
define('SUCCESS_EDIT', 'Chỉnh sửa dữ liệu thành công!');
define('SUCCESS_CHANGE', 'Cập nhật dữ liệu thành công!');
define('SUCCESS_CHANGE_PASSWORD', 'Thay thổi mật khẩu thành công!');
define('SUCCESS_RESET_PASSWORD', 'Reset mật khẩu thành công!');
define('FAIL_LOGIN', 'Thông tin đăng nhập không chính xác. Vui lòng thử lại!');
define('FAIL_ACTION', 'Xảy ra lỗi, vui lòng thử lại!');
    